# Monitoring EXP — V5 Scanner Ringan

Versi ini memperbaiki scanner barcode native agar lebih mirip scanner barcode umum dan lebih ringan:
- CameraX + ML Kit native
- Analisis frame hanya satu per satu (mencegah antrean frame)
- Resolusi analisis 1280x720 + KEEP_ONLY_LATEST
- Format barcode umum diprioritaskan
- Flash/tombol lampu
- Permission kamera dengan alur Pengaturan bila ditolak
- Callback barcode diperbaiki agar produk existing dibuka berdasarkan index `products` yang benar
- Permission notifikasi Android 13+ sudah dideklarasikan

Catatan: source ini belum dikompilasi menjadi APK di lingkungan ini. Build APK dilakukan melalui Android Studio.
