package com.supermarket.monitoringexp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;
import androidx.appcompat.app.AlertDialog;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    private WebView webView;

    private final ActivityResultLauncher<Intent> scannerLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK &&
                                result.getData() != null) {
                            String value = result.getData().getStringExtra("barcode_result");
                            if (value != null && webView != null) {
                                String js = "window.onNativeBarcodeScanned("
                                        + org.json.JSONObject.quote(value) + ");";
                                webView.post(() -> webView.evaluateJavascript(js, null));
                            }
                        }
                    });

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            launchScanner();
                        } else {
                            showCameraPermissionHelp();
                        }
                    });

    private void showCameraPermissionHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Izin Kamera Diperlukan")
                .setMessage("Monitoring EXP membutuhkan akses kamera untuk membaca barcode. Silakan izinkan kamera pada Pengaturan aplikasi.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Buka Pengaturan", (d, w) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .show();
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void launchScanner() {
        scannerLauncher.launch(new Intent(this, ScannerActivity.class));
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void playReminderVoice() {
            runOnUiThread(() -> VoiceReminder.play(MainActivity.this));
        }

        @JavascriptInterface
        public void scanBarcode() {
            runOnUiThread(() -> {
                if (ContextCompat.checkSelfPermission(
                        MainActivity.this, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) {
                    launchScanner();
                } else {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
                }
            });
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
