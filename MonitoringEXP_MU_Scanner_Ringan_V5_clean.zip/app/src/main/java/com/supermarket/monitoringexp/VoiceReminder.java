package com.supermarket.monitoringexp;

import android.content.Context;
import android.media.MediaPlayer;

public final class VoiceReminder {
    private static MediaPlayer player;

    private VoiceReminder() {}

    public static void play(Context context) {
        stop();
        player = MediaPlayer.create(context, R.raw.voice_reminder);
        if (player != null) {
            player.setOnCompletionListener(mp -> {
                mp.release();
                player = null;
            });
            player.start();
        }
    }

    public static void stop() {
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            player.release();
            player = null;
        }
    }
}
