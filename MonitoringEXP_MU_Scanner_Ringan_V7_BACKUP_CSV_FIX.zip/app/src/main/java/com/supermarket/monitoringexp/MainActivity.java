package com.supermarket.monitoringexp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.provider.Settings;
import androidx.appcompat.app.AlertDialog;
import android.os.Bundle;
import android.os.Build;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    private WebView webView;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime;
    private String pendingSaveName;

    private final ActivityResultLauncher<Intent> scannerLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK &&
                                result.getData() != null) {
                            String value = result.getData().getStringExtra("barcode_result");
                            if (value != null && webView != null) {
                                String js = "window.onNativeBarcodeScanned("
                                        + org.json.JSONObject.quote(value) + ");";
                                webView.post(() -> webView.evaluateJavascript(js, null));
                            }
                        }
                    });

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            launchScanner();
                        } else {
                            showCameraPermissionHelp();
                        }
                    });

    private void showCameraPermissionHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Izin Kamera Diperlukan")
                .setMessage("Monitoring EXP membutuhkan akses kamera untuk membaca barcode. Silakan izinkan kamera pada Pengaturan aplikasi.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Buka Pengaturan", (d, w) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .show();
    }

    private final ActivityResultLauncher<Intent> csvImportLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                        Uri uri = result.getData().getData();
                        if (uri == null) return;
                        try (InputStream in = getContentResolver().openInputStream(uri)) {
                            byte[] bytes = readAll(in);
                            String csv = new String(bytes, StandardCharsets.UTF_8);
                            String js = "window.onNativeCSVImported(" +
                                    org.json.JSONObject.quote(csv) + ");";
                            webView.post(() -> webView.evaluateJavascript(js, null));
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Import CSV gagal: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });

    private final ActivityResultLauncher<Intent> fileSaveLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() != RESULT_OK || result.getData() == null) {
                            pendingSaveBytes = null;
                            pendingSaveMime = null;
                            pendingSaveName = null;
                            return;
                        }
                        Uri uri = result.getData().getData();
                        if (uri == null || pendingSaveBytes == null) return;
                        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                            if (out == null) throw new java.io.IOException("Output stream tidak tersedia");
                            out.write(pendingSaveBytes);
                            out.flush();
                            Toast.makeText(MainActivity.this, "File berhasil disimpan", Toast.LENGTH_LONG).show();
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Gagal menyimpan file: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        } finally {
                            pendingSaveBytes = null;
                            pendingSaveMime = null;
                            pendingSaveName = null;
                        }
                    });

    private static byte[] readAll(InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    private boolean saveToDownloads(byte[] bytes, String fileName, String mimeType) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false;
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
            values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType);
            values.put(MediaStore.Downloads.RELATIVE_PATH, "Download/MonitoringEXP");
            values.put(MediaStore.Downloads.IS_PENDING, 1);
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) return false;
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new java.io.IOException("Output stream tidak tersedia");
                out.write(bytes);
                out.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Downloads.IS_PENDING, 0);
            getContentResolver().update(uri, done, null, null);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void launchScanner() {
        scannerLauncher.launch(new Intent(this, ScannerActivity.class));
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void playReminderVoice() {
            runOnUiThread(() -> VoiceReminder.play(MainActivity.this));
        }

        @JavascriptInterface
        public void importCSV() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/csv", "text/plain", "application/csv", "application/vnd.ms-excel", "application/octet-stream"});
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { csvImportLauncher.launch(intent); }
                catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void saveTextFile(String content, String fileName, String mimeType) {
            runOnUiThread(() -> {
                try {
                    byte[] bytes = content.getBytes(StandardCharsets.UTF_8);
                    if (saveToDownloads(bytes, fileName, mimeType)) {
                        Toast.makeText(MainActivity.this, "Berhasil disimpan ke Download/MonitoringEXP/" + fileName, Toast.LENGTH_LONG).show();
                        return;
                    }
                    // Fallback untuk Android lama atau jika MediaStore gagal.
                    pendingSaveBytes = bytes;
                    pendingSaveMime = mimeType;
                    pendingSaveName = fileName;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mimeType == null || mimeType.isEmpty() ? "application/octet-stream" : mimeType);
                    intent.putExtra(Intent.EXTRA_TITLE, fileName);
                    intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    fileSaveLauncher.launch(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Export/Backup gagal: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void scanBarcode() {
            runOnUiThread(() -> {
                if (ContextCompat.checkSelfPermission(
                        MainActivity.this, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) {
                    launchScanner();
                } else {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
                }
            });
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
