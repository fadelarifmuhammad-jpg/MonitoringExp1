package com.supermarket.monitoringexp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.provider.Settings;
import androidx.appcompat.app.AlertDialog;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    private WebView webView;
    private byte[] pendingSaveBytes;
    private String pendingSaveMime;

    private final ActivityResultLauncher<Intent> scannerLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() == RESULT_OK &&
                                result.getData() != null) {
                            String value = result.getData().getStringExtra("barcode_result");
                            if (value != null && webView != null) {
                                String js = "window.onNativeBarcodeScanned("
                                        + org.json.JSONObject.quote(value) + ");";
                                webView.post(() -> webView.evaluateJavascript(js, null));
                            }
                        }
                    });

    private final ActivityResultLauncher<String> cameraPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    granted -> {
                        if (granted) {
                            launchScanner();
                        } else {
                            showCameraPermissionHelp();
                        }
                    });

    private void showCameraPermissionHelp() {
        new AlertDialog.Builder(this)
                .setTitle("Izin Kamera Diperlukan")
                .setMessage("Monitoring EXP membutuhkan akses kamera untuk membaca barcode. Silakan izinkan kamera pada Pengaturan aplikasi.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Buka Pengaturan", (d, w) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .show();
    }

    private final ActivityResultLauncher<Intent> csvImportLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                        Uri uri = result.getData().getData();
                        if (uri == null) return;
                        try (InputStream in = getContentResolver().openInputStream(uri)) {
                            byte[] bytes = readAll(in);
                            String csv = new String(bytes, StandardCharsets.UTF_8);
                            String js = "window.onNativeCSVImported(" +
                                    org.json.JSONObject.quote(csv) + ");";
                            webView.post(() -> webView.evaluateJavascript(js, null));
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Import CSV gagal: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });

    private final ActivityResultLauncher<Intent> fileSaveLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.StartActivityForResult(),
                    result -> {
                        if (result.getResultCode() != RESULT_OK || result.getData() == null) {
                            pendingSaveBytes = null;
                            return;
                        }
                        Uri uri = result.getData().getData();
                        if (uri == null || pendingSaveBytes == null) return;
                        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                            out.write(pendingSaveBytes);
                            out.flush();
                            Toast.makeText(MainActivity.this, "File berhasil disimpan", Toast.LENGTH_SHORT).show();
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Gagal menyimpan file: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        } finally {
                            pendingSaveBytes = null;
                        }
                    });

    private static byte[] readAll(InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void launchScanner() {
        scannerLauncher.launch(new Intent(this, ScannerActivity.class));
    }

    private class AndroidBridge {
        @JavascriptInterface
        public void playReminderVoice() {
            runOnUiThread(() -> VoiceReminder.play(MainActivity.this));
        }

        @JavascriptInterface
        public void importCSV() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("text/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/csv", "text/plain", "application/csv", "application/vnd.ms-excel"});
                try { csvImportLauncher.launch(intent); }
                catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Pemilih file tidak tersedia", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void saveTextFile(String content, String fileName, String mimeType) {
            runOnUiThread(() -> {
                try {
                    pendingSaveBytes = content.getBytes(StandardCharsets.UTF_8);
                    pendingSaveMime = mimeType;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(mimeType == null || mimeType.isEmpty() ? "text/plain" : mimeType);
                    intent.putExtra(Intent.EXTRA_TITLE, fileName);
                    fileSaveLauncher.launch(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Export gagal: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void scanBarcode() {
            runOnUiThread(() -> {
                if (ContextCompat.checkSelfPermission(
                        MainActivity.this, Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) {
                    launchScanner();
                } else {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
                }
            });
        }
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
