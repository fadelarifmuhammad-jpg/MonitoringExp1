# Monitoring EXP – Final

Versi ini mempertahankan konsep dashboard merah/Manchester United dan menambahkan:

- Database produk (barcode, nama, tanggal expired)
- Dashboard Total / Expired / <=7 hari / <=30 hari
- Pencarian dan filter status
- Google Code Scanner untuk barcode
- Export CSV
- Backup JSON
- Import CSV
- **Email Expired**: membuat `Produk_Expired.csv` otomatis di cache dan memasangnya sebagai attachment pada email/share intent
- FileProvider sehingga pengguna tidak perlu membuka File Manager untuk mengambil lampiran

## Build di GitHub Actions

Gunakan Android Gradle Plugin 8.6.1, compileSdk 35, Java 17 dan Gradle 8.9.
