package com.supermarket.monitoringexp;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.mlkit.vision.barcode.*;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning;
import java.text.*;
import java.util.*;

public class AddProductActivity extends AppCompatActivity {
    EditText barcode,name,expiry; Db db;
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new Db(this);build();if(getIntent().getBooleanExtra("scanNow",false))scan();}
    TextView label(String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(14);t.setPadding(0,10,0,4);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    void build(){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(20,15,20,20);
        TextView h=label("TAMBAH PRODUK");h.setTextSize(21);h.setTextColor(Color.rgb(213,0,0));r.addView(h);
        r.addView(label("Barcode")); LinearLayout br=new LinearLayout(this);barcode=new EditText(this);barcode.setSingleLine();barcode.setHint("Scan atau ketik barcode");Button sc=btn("📷 Scan");br.addView(barcode,new LinearLayout.LayoutParams(0,-2,1));br.addView(sc,new LinearLayout.LayoutParams(-2,-2));r.addView(br);
        r.addView(label("Nama Produk"));name=new EditText(this);name.setSingleLine();name.setHint("Nama produk");r.addView(name);
        r.addView(label("Tanggal Expired"));expiry=new EditText(this);expiry.setSingleLine();expiry.setHint("YYYY-MM-DD");r.addView(expiry);
        Button save=btn("Simpan Produk");r.addView(save);Button back=btn("Batal");r.addView(back);setContentView(r);
        sc.setOnClickListener(v->scan());save.setOnClickListener(v->{String b=barcode.getText().toString().trim(),n=name.getText().toString().trim(),e=expiry.getText().toString().trim();if(n.isEmpty()||e.isEmpty()){Toast.makeText(this,"Nama dan tanggal expired wajib diisi.",Toast.LENGTH_SHORT).show();return;}try{new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e);}catch(Exception x){Toast.makeText(this,"Tanggal harus YYYY-MM-DD.",Toast.LENGTH_SHORT).show();return;}db.add(b,n,e);finish();});back.setOnClickListener(v->finish());
    }
    void scan(){
        GmsBarcodeScanning.getClient(this).startScan().addOnSuccessListener(barcode1->{barcode.setText(barcode1.getRawValue());}).addOnFailureListener(e->{Toast.makeText(this,"Scanner gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();});
    }
}
