package com.supermarket.monitoringexp;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.*;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    Db db; LinearLayout list; EditText search; Spinner filter; TextView total,expired,seven,thirty;

    int red=Color.rgb(213,0,0);
    @Override public void onCreate(Bundle b){
        super.onCreate(b); db=new Db(this); build(); refresh();
    }
    TextView tv(String s,int sp){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(35,35,35));
        t.setPadding(16,12,16,12); return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(13); b.setAllCaps(false); return b;
    }
    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(248,248,248));
        TextView head=tv("MONITORING EXP",21); head.setTextColor(Color.WHITE); head.setGravity(Gravity.CENTER_VERTICAL); head.setPadding(20,18,20,18); head.setBackgroundColor(red);
        root.addView(head,new LinearLayout.LayoutParams(-1,-2));

        LinearLayout cards=new LinearLayout(this); cards.setPadding(8,8,8,4);
        total=card("Total Produk"); expired=card("Expired"); seven=card("≤ 7 Hari"); thirty=card("≤ 30 Hari");
        cards.addView(total,new LinearLayout.LayoutParams(0,-2,1)); cards.addView(expired,new LinearLayout.LayoutParams(0,-2,1));
        cards.addView(seven,new LinearLayout.LayoutParams(0,-2,1)); cards.addView(thirty,new LinearLayout.LayoutParams(0,-2,1)); root.addView(cards);

        search=new EditText(this); search.setHint("Cari barcode atau nama produk…"); search.setSingleLine(); search.setPadding(16,4,16,4);
        root.addView(search,new LinearLayout.LayoutParams(-1,54));
        filter=new Spinner(this); String[] fs={"Semua Status","Expired","≤ 7 Hari","≤ 30 Hari"}; filter.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,fs));
        root.addView(filter,new LinearLayout.LayoutParams(-1,48));

        LinearLayout actions=new LinearLayout(this); actions.setPadding(8,3,8,3);
        Button add=btn("+ Produk"), scan=btn("📷 Scan Barcode"), email=btn("📧 Email Expired");
        actions.addView(add,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(scan,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(email,new LinearLayout.LayoutParams(0,-2,1)); root.addView(actions);
        LinearLayout actions2=new LinearLayout(this); actions2.setPadding(8,0,8,3);
        Button csv=btn("↓ Export CSV"), backup=btn("💾 Backup JSON"), imp=btn("↑ Import CSV");
        actions2.addView(csv,new LinearLayout.LayoutParams(0,-2,1)); actions2.addView(backup,new LinearLayout.LayoutParams(0,-2,1)); actions2.addView(imp,new LinearLayout.LayoutParams(0,-2,1)); root.addView(actions2);

        LinearLayout tableHead=new LinearLayout(this); tableHead.setBackgroundColor(Color.LTGRAY);
        String[] hs={"No","Barcode","Nama Produk","Expired"}; float[] wt={.6f,1.7f,2.2f,1.5f};
        for(int i=0;i<hs.length;i++){TextView h=tv(hs[i],12);h.setTypeface(null,1);tableHead.addView(h,new LinearLayout.LayoutParams(0,-2,wt[i]));}
        root.addView(tableHead);
        ScrollView sv=new ScrollView(this); list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); nav.setBackgroundColor(Color.WHITE);
        TextView d=tv("⌂\nDashboard",12);d.setGravity(Gravity.CENTER); TextView n=tv("+\nTambah",12);n.setGravity(Gravity.CENTER);
        nav.addView(d,new LinearLayout.LayoutParams(0,65,1));nav.addView(n,new LinearLayout.LayoutParams(0,65,1));root.addView(nav);
        setContentView(root);

        add.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class)));
        n.setOnClickListener(v->startActivity(new Intent(this,AddProductActivity.class)));
        scan.setOnClickListener(v->scanBarcode());
        email.setOnClickListener(v->emailExpired());
        csv.setOnClickListener(v->exportCsv());
        backup.setOnClickListener(v->backupJson());
        imp.setOnClickListener(v->importCsv());
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){refresh();} public void afterTextChanged(android.text.Editable e){}});
        filter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){refresh();}});
    }
    TextView card(String title){ TextView t=tv(title+"\n0",11);t.setGravity(Gravity.CENTER);t.setBackgroundColor(Color.WHITE);t.setPadding(4,10,4,10);return t; }

    long days(String e){
        try{ Date d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(e); long x=d.getTime()-System.currentTimeMillis(); return (long)Math.floor(x/86400000.0); }catch(Exception ex){return 999999;}
    }
    void refresh(){
        if(list==null)return;
        List<Product> ps=search.getText().toString().trim().isEmpty()?db.all():db.search(search.getText().toString().trim());
        int ex=0,s7=0,s30=0;
        for(Product p:db.all()){long d=days(p.expiry);if(d<0)ex++;else if(d<=7)s7++;else if(d<=30)s30++;}
        total.setText("Total Produk\n"+db.all().size());expired.setText("Expired\n"+ex);seven.setText("≤ 7 Hari\n"+s7);thirty.setText("≤ 30 Hari\n"+s30);
        list.removeAllViews(); int no=1; String f=filter.getSelectedItem()==null?"Semua Status":filter.getSelectedItem().toString();
        for(Product p:ps){long d=days(p.expiry);boolean ok=f.equals("Semua Status")||(f.equals("Expired")&&d<0)||(f.equals("≤ 7 Hari")&&d>=0&&d<=7)||(f.equals("≤ 30 Hari")&&d>=0&&d<=30);if(!ok)continue;
            LinearLayout row=new LinearLayout(this);row.setBackgroundColor(no%2==0?Color.WHITE:Color.rgb(245,245,245));
            String[] vals={""+no++,p.barcode,p.name,p.expiry};float[] wt={.6f,1.7f,2.2f,1.5f};
            for(int i=0;i<4;i++){TextView x=tv(vals[i],11);row.addView(x,new LinearLayout.LayoutParams(0,-2,wt[i]));}
            list.addView(row);
        }
    }
    void scanBarcode(){
        startActivity(new Intent(this,AddProductActivity.class).putExtra("scanNow",true));
    }
    void emailExpired(){
        ArrayList<Product> ex=new ArrayList<>();for(Product p:db.all())if(days(p.expiry)<0)ex.add(p);
        if(ex.isEmpty()){new AlertDialog.Builder(this).setTitle("Email Expired").setMessage("Tidak ada produk expired.").setPositiveButton("OK",null).show();return;}
        try{
            File f=new File(getCacheDir(),"Produk_Expired.csv");BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8));
            w.write("No,Barcode,Nama Produk,Tanggal Expired\n");int i=1;for(Product p:ex){w.write(i++ +","+Csv.esc(p.barcode)+","+Csv.esc(p.name)+","+Csv.esc(p.expiry)+"\n");}w.close();
            Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
            Intent in=new Intent(Intent.ACTION_SEND);in.setType("text/csv");in.putExtra(Intent.EXTRA_EMAIL,new String[]{""});in.putExtra(Intent.EXTRA_SUBJECT,"Laporan Produk Expired");in.putExtra(Intent.EXTRA_TEXT,"Terlampir laporan produk yang sudah expired.");in.putExtra(Intent.EXTRA_STREAM,u);in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(in,"Kirim laporan expired"));
        }catch(Exception e){Toast.makeText(this,"Gagal membuat lampiran: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    void exportCsv(){try{File f=new File(getExternalFilesDir(null),"MonitoringEXP.csv");BufferedWriter w=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8));w.write("Barcode,Nama Produk,Tanggal Expired\n");for(Product p:db.all())w.write(Csv.esc(p.barcode)+","+Csv.esc(p.name)+","+Csv.esc(p.expiry)+"\n");w.close();share(f,"text/csv","Export Monitoring EXP");}catch(Exception e){Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();}}
    void backupJson(){try{File f=new File(getExternalFilesDir(null),"MonitoringEXP_Backup.json");BufferedWriter w=new BufferedWriter(new FileWriter(f));w.write("[");int i=0;for(Product p:db.all()){if(i++>0)w.write(",");w.write("{\"barcode\":\""+json(p.barcode)+"\",\"name\":\""+json(p.name)+"\",\"expiry\":\""+json(p.expiry)+"\"}");}w.write("]");w.close();share(f,"application/json","Backup Monitoring EXP");}catch(Exception e){Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();}}
    String json(String s){return s==null?"":s.replace("\\","\\\\").replace(""","\\\"");}
    void share(File f,String type,String title){Uri u=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);Intent in=new Intent(Intent.ACTION_SEND);in.setType(type);in.putExtra(Intent.EXTRA_STREAM,u);in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(in,title));}
    void importCsv(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("text/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,42);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==42&&c==RESULT_OK&&d!=null){try{BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(d.getData()),StandardCharsets.UTF_8));String line;boolean first=true;db.clear();while((line=br.readLine())!=null){if(first){first=false;continue;}List<String>a=Csv.parseLine(line);if(a.size()>=3)db.add(a.get(0),a.get(1),a.size()>2?a.get(2):"");}br.close();refresh();Toast.makeText(this,"Import CSV berhasil.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Import gagal: "+e.getMessage(),Toast.LENGTH_LONG).show();}}}
    @Override protected void onResume(){super.onResume();if(db!=null)refresh();}
}
