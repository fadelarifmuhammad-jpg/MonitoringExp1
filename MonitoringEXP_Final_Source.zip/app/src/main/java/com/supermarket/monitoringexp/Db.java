package com.supermarket.monitoringexp;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class Db extends SQLiteOpenHelper {
    public Db(Context c){ super(c,"monitoring_exp.db",null,1); }
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT, name TEXT NOT NULL, expiry TEXT NOT NULL)");
    }
    public void onUpgrade(SQLiteDatabase db,int oldV,int newV){}
    public long add(String barcode,String name,String expiry){
        ContentValues v=new ContentValues(); v.put("barcode",barcode); v.put("name",name); v.put("expiry",expiry);
        return getWritableDatabase().insert("products",null,v);
    }
    public void clear(){ getWritableDatabase().delete("products",null,null); }
    public List<Product> all(){
        ArrayList<Product> out=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT id,barcode,name,expiry FROM products ORDER BY id DESC",null);
        while(c.moveToNext()) out.add(new Product(c.getLong(0),c.getString(1),c.getString(2),c.getString(3)));
        c.close(); return out;
    }
    public List<Product> search(String q){
        ArrayList<Product> out=new ArrayList<>();
        String like="%"+q+"%";
        Cursor c=getReadableDatabase().rawQuery("SELECT id,barcode,name,expiry FROM products WHERE barcode LIKE ? OR name LIKE ? ORDER BY id DESC",new String[]{like,like});
        while(c.moveToNext()) out.add(new Product(c.getLong(0),c.getString(1),c.getString(2),c.getString(3)));
        c.close(); return out;
    }
}
